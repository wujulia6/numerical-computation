
import torch
import matplotlib.pyplot as plt
from functorch import vmap
from my_random_fields import GRF_Mattern
import numpy as np

class BurgersEq1D():
    def __init__(self,
                 xmin=0,
                 xmax=1,
                #  ymin=0,
                #  ymax=1,
                #  dx=0.01,
                #  dy=0.01,
                 Nx=100,
                #  Ny=100,
                 nu=0.01,
                 dt=1e-3,
                 tend=1.0,
                 device=None,
                 dtype=torch.float64,
                 ):
        self.xmin = xmin
        self.xmax = xmax
        self.Nx = Nx
        x = torch.linspace(xmin, xmax, Nx + 1, device=device, dtype=dtype)[:-1]
        self.x = x
        # self.y = y
        self.dx = x[1] - x[0]
        # self.dy = y[1] - y[0]
        # self.X, self.Y = jnp.meshgrid(x,y,indexing='ij')
        self.nu = nu
        self.u = torch.zeros_like(x, device=device)
        self.u0 = torch.zeros_like(self.u, device=device)
        self.dt = dt
        self.tend = tend
        self.t = 0
        self.it = 0
        self.U = []
        self.T = []
        self.device = device
        
    

    # All Central Differencing Functions are 4th order.  These are used to compute ann inputs.
    def CD_i(self, data, axis, dx):
        data_m2 = torch.roll(data,shifts=2,dims=axis)
        data_m1 = torch.roll(data,shifts=1,dims=axis)
        data_p1 = torch.roll(data,shifts=-1,dims=axis)
        data_p2 = torch.roll(data,shifts=-2,dims=axis)
        data_diff_i = (data_m2 - 8.0*data_m1 + 8.0*data_p1 - data_p2)/(12.0*dx)
        return data_diff_i

    def CD_ij(self, data, axis_i, axis_j, dx, dy):
        data_diff_i = self.CD_i(data,axis_i,dx)
        data_diff_ij = self.CD_i(data_diff_i,axis_j,dy)
        return data_diff_ij

    def CD_ii(self, data, axis, dx):
        data_m2 = torch.roll(data,shifts=2,dims=axis)
        data_m1 = torch.roll(data,shifts=1,dims=axis)
        data_p1 = torch.roll(data,shifts=-1,dims=axis)
        data_p2 = torch.roll(data,shifts=-2,dims=axis)
        data_diff_ii = (-data_m2 + 16.0*data_m1 - 30.0*data + 16.0*data_p1 -data_p2)/(12.0*dx**2)
        return data_diff_ii

    def Dx(self, data):
        data_dx = self.CD_i(data=data, axis=0, dx=self.dx)
        return data_dx

    def Dxx(self, data):
        data_dxx = self.CD_ii(data, axis=0, dx=self.dx)
        return data_dxx

    def burgers_calc_RHS(self, u):
        u_xx = self.Dxx(u)
        u2 = u**2.0
        u2_x = self.Dx(u2)
        u_RHS = -0.5*u2_x + self.nu*u_xx
        return u_RHS
        
    def update_field(self, field, RHS, step_frac):
        field_new = field + self.dt*step_frac*RHS
        return field_new
        

    def rk4_merge_RHS(self, field, RHS1, RHS2, RHS3, RHS4):
        field_new = field + self.dt/6.0*(RHS1 + 2*RHS2 + 2.0*RHS3 + RHS4)
        return field_new

    def burgers_rk4(self, u, t=0):
        u_RHS1 = self.burgers_calc_RHS(u)
        t1 = t + 0.5*self.dt
        u1 = self.update_field(u, u_RHS1, step_frac=0.5)
        
        u_RHS2 = self.burgers_calc_RHS(u1)
        t2 = t + 0.5*self.dt
        u2 = self.update_field(u, u_RHS2, step_frac=0.5)
        
        u_RHS3 = self.burgers_calc_RHS(u2)
        t3 = t + self.dt
        u3 = self.update_field(u, u_RHS3, step_frac=1.0)
        
        u_RHS4 = self.burgers_calc_RHS(u3)
        
        t_new = t + self.dt
        u_new = self.rk4_merge_RHS(u, u_RHS1, u_RHS2, u_RHS3, u_RHS4)
        
        return u_new, t_new


        
    def burgers_driver(self, u0, save_interval=10, plot_interval=0):
        self.u0 = u0[:self.Nx]
        self.u = self.u0
        self.t = 0
        self.it = 0
        self.T = []
        self.U = []
        
        if save_interval != 0 and self.it % save_interval == 0:
            self.U.append(self.u)
            self.T.append(self.t)
        # Compute equations
        while self.t < self.tend:
            self.u, self.t = self.burgers_rk4(self.u, self.t)
            
            self.it += 1
            if save_interval != 0 and self.it % save_interval == 0:
                self.U.append(self.u)
                self.T.append(self.t)

        return torch.stack(self.U)
    
def main():
    N = 128
    dim = 1
    l = 0.1
    L = 1.0
    sigma = 0.5 #2.0
    Nu = None
    Nsamples=3
    nu=0.01
    Nx = N 
    dt = 1.0e-4

    grf = GRF_Mattern(dim, N, length=L, nu=Nu, l=l, sigma=sigma, boundary="periodic")
    U0 = grf.sample(Nsamples)

    burgers_eq = BurgersEq1D(Nx=Nx, nu=nu, dt=dt)
    save_interval = int(1e-2/dt)
    # U = vmap(burgers_eq.burgers_driver, in_dims=(0, None))(U0, save_interval) 
    U = vmap(burgers_eq.burgers_driver, in_dims=(0, None))(U0, save_interval)  
    U_reshaped = U[2]
    U0_reshaped = U0[2]

    Nt=101

    x = np.linspace(0,1,Nx+1)[:-1]
    t = np.linspace(0,1,Nt+1)[:-1]
    X,T = np.meshgrid(x,t)
    # X = xx.flatten()
    # T = tt.flatten()

    fig = plt.figure(figsize=(12,5))
    plt.subplot(1,2,1)

    plt.plot(x, U0_reshaped)
    plt.xlabel('$x$')
    plt.ylabel('$u$')
    plt.title('Intial Condition $u_0(x)$')
    plt.xlim([0,1])
    plt.tight_layout()

    plt.subplot(1,2,2)
    # plt.pcolor(XX,TT, S_test, cmap='jet')
    plt.pcolormesh(X, T, U_reshaped, cmap='jet', shading='gouraud')
    plt.colorbar()
    plt.xlabel('$x$')
    plt.ylabel('$t$')
    plt.title(f'$u(x,t)$')
    plt.tight_layout()
    plt.axis('square')
    plt.savefig("result.jpg")
    a=10

if __name__ == '__main__':
    main()